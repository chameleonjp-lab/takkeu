# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: iphone-performance.spec.ts >> LAN HTTP相当の非secure originでも起動し60秒の診断記録を保存できる
- Location: tests/browser/iphone-performance.spec.ts:15:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

Expected: []
Received: undefined
```

# Page snapshot

```yaml
- generic:
  - main [ref=e1]:
    - generic [ref=e2]:
      - generic "卓球ゲームの描画領域" [ref=e5]
      - generic:
        - generic:
          - generic: RALLY
          - status "ラリー数": "1500"
        - generic:
          - generic: 残球数
          - status "残球数": "30"
        - generic:
          - generic: 落球数
          - status "落球数": 0 / 100
        - status: スマッシュがくる！
        - status
      - dialog [ref=e6]:
        - generic [ref=e7]:
          - paragraph [ref=e8]: PAUSE
          - heading "ひと休み" [level=2] [ref=e9]
          - paragraph [ref=e10]: 動作が一時的に遅くなりました。準備ができたら再開してください。
          - status [ref=e11]: 一時停止中。再開ボタンで続けられます。
          - button "つづける" [active] [ref=e12] [cursor=pointer]:
            - text: つづける
            - generic [aria-hidden] [ref=e13]: →
          - button "最初からやり直す" [ref=e14] [cursor=pointer]
          - button "ホームへ" [ref=e15] [cursor=pointer]
          - group "音声" [ref=e16]:
            - button "音：オン" [ref=e18] [cursor=pointer]
            - button "音声を再試行" [ref=e19] [cursor=pointer]
            - generic [ref=e20]:
              - text: 効果音の音量
              - slider "効果音の音量" [ref=e21]: "0.65"
  - button "診断" [ref=e22] [cursor=pointer]
  - region "実機診断専用" [ref=e23]:
    - strong [ref=e24]: 実機診断専用・本番配布禁止
    - paragraph [ref=e25]: ゲームを開始してから計測します。計測中はこのパネルを隠します。
    - generic [ref=e26]:
      - text: 開始ラリー
      - combobox "開始ラリー" [ref=e27]:
        - option "1500" [selected]
        - option "2600"
        - option "3000"
        - option "4000"
    - generic [ref=e28]:
      - checkbox "30球自動返球（性能測定用）" [checked] [ref=e29]
      - text: 30球自動返球（性能測定用）
    - paragraph [ref=e30]: 画質・音量はゲームの設定で選択してください。
    - button "60秒計測" [ref=e31] [cursor=pointer]
    - button "パネルを閉じる" [ref=e32] [cursor=pointer]
    - generic [ref=e33]: "{ \"schema\": \"iphone-real-device-v1\", \"time\": \"2026-10-26T00:01:02.110Z\", \"userAgent\": \"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36\", \"devicePixelRatio\": 1, \"viewport\": { \"width\": 1280, \"height\": 720 }, \"drawingSize\": { \"width\": 1280, \"height\": 720 }, \"initialScore\": 1500, \"autoplay\": true, \"durationMs\": 61000, \"p50Ms\": 61000, \"p95Ms\": 61000, \"p99Ms\": 61000, \"fraction25\": 0, \"simulationSeconds\": 0, \"continuousRunning30\": false, \"finalPhase\": \"paused\", \"pauseReason\": \"slow-frame\", \"initialAudio\": { \"created\": 3, \"sourceCreated\": 0, \"liveNodes\": 3, \"liveSources\": 0, \"layeredVoices\": 0, \"peakNodes\": 3, \"peakSources\": 0, \"peakVoices\": 0 }, \"finalAudio\": { \"created\": 3, \"sourceCreated\": 0, \"liveNodes\": 3, \"liveSources\": 0, \"layeredVoices\": 0, \"peakNodes\": 3, \"peakSources\": 0, \"peakVoices\": 0 }, \"resources\": { \"geometries\": 57, \"textures\": 4, \"programs\": 17, \"drawCalls\": 30, \"particles\": 1, \"particleCapacity\": 11776, \"rallyEffects\": { \"activeEffects\": [ \"background-threads\", \"single-halo\", \"meteor\", \"tricolor-crossing\" ], \"tableQuads\": 138, \"worldQuads\": 332, \"particleCount\": 1, \"finalPhase\": null, \"capacity\": 10240, \"geometries\": 4, \"materials\": 4, \"nodes\": 6, \"drawCalls\": 3, \"disposed\": false } }, \"samples\": \"1件（保存JSONに全件）\", \"note\": \"実機で開いた場合のみ実機測定。入力遅延・視認性・音質・温度は人間の別記録が必要。Linux比較とは初期化/収集方式が異なる。\" }"
    - link "測定JSONを保存" [ref=e34] [cursor=pointer]:
      - /url: blob:http://device-lan.invalid/99ba93b4-7897-4b6f-957c-1b4195a828b5
```

# Test source

```ts
  1  | import { test,expect,waitForStart } from '../helpers/browserTest';
  2  | 
  3  | test('test-only iPhone recorder requires started play and blocks off-origin fetch',async({page})=>{
  4  |   const external:string[]=[];
  5  |   page.on('request',r=>{if(!r.url().startsWith('http://127.0.0.1:4173'))external.push(r.url());});
  6  |   await page.goto('/tests/fixtures/performance-iphone.html');
  7  |   const panel=page.getByRole('region',{name:'実機診断専用'});
  8  |   await expect(panel).toBeVisible();
  9  |   await page.getByRole('button',{name:'60秒計測',exact:true}).click();
  10 |   await expect(panel).toContainText('先に');
  11 |   const blocked=await page.evaluate(()=>fetch('https://not-allowed.invalid/score').then(()=>false,error=>String(error).includes('外部通信を遮断')));
  12 |   expect(blocked).toBe(true);expect(external).toEqual([]);
  13 | });
  14 | 
  15 | test('LAN HTTP相当の非secure originでも起動し60秒の診断記録を保存できる',async({page})=>{
  16 |   test.setTimeout(120_000);
  17 |   const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));
  18 |   // Route an intentionally insecure origin entirely to the local test server.
  19 |   // No external hostname is resolved or contacted.
  20 |   await page.route('http://device-lan.invalid/**',async route=>{
  21 |     const url=new URL(route.request().url());
  22 |     await route.fulfill({response:await route.fetch({url:`http://127.0.0.1:4173${url.pathname}${url.search}`})});
  23 |   });
  24 |   await page.routeWebSocket('**/*',socket=>socket.close());
  25 |   await page.clock.install({time:new Date('2026-10-26T00:00:00Z')});
  26 |   await page.clock.pauseAt(new Date('2026-10-26T00:00:01Z'));
  27 |   await page.goto('http://device-lan.invalid/tests/fixtures/performance-iphone.html');
  28 |   expect(await page.evaluate(()=>isSecureContext)).toBe(false);
  29 |   await page.getByRole('button',{name:'パネルを閉じる',exact:true}).click();
  30 |   await page.getByRole('button',{name:'はじめる',exact:true}).click();await waitForStart(page);
  31 |   await page.getByRole('button',{name:'診断',exact:true}).click();
  32 |   await page.getByRole('button',{name:'60秒計測',exact:true}).click();
  33 |   // Exercise recorder completion only; fast-forward is deliberately NOT a
  34 |   // device performance result and the unchanged slow-frame guard may pause.
  35 |   await page.clock.fastForward(61000);
  36 |   const save=page.getByRole('link',{name:'測定JSONを保存',exact:true});await expect(save).toBeVisible();
  37 |   const record=await save.evaluate(async element=>JSON.parse(await (await fetch((element as HTMLAnchorElement).href)).text()));
  38 |   expect(record.durationMs).toBeGreaterThanOrEqual(60000);
> 39 |   expect(record.errors).toEqual([]);expect(record.secureContext).toBe(false);
     |                         ^ Error: expect(received).toEqual(expected) // deep equality
  40 |   expect(errors).toEqual([]);
  41 | });
  42 | 
```